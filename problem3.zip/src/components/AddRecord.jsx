import axios from 'axios'
import React, { useEffect, useState } from 'react'

const AddRecord = () => {
  const [userRecord, setUserRrecord] = useState([]);
  console.log(userRecord);
  const api = "https://swapi.dev/api/people/"

  const record_func = () => {
    axios.get(api, {
      headers: 'Accept: application/json'
    }).then((resp) => {

      // console.log(resp.data.results);
      setUserRrecord(resp.data.results)
    }).catch((err) => {
      console.log("dfdf");
      // console.log(err);
    })
  }


  useEffect(() => {
    record_func()

  }, []);



  const handleDelete = (item) => {
    const newdata = userRecord.filter((el) => el != item)
    setUserRrecord(newdata)
  }




  return (
    <div>
      <div>
        <div style={{ display: "flex", width: "100%", justifyContent: "between", margin: "0 auto" }}>
          <span style={{ fontSize: "24px" }}>Name</span>

        </div>
        <div>
          <div >

            {

              userRecord.map((item, index) => {
                return <div style={{ flexDirection: "column", display: 'flex', lineHeight: "40px" }}>
                  <div style={{ display: 'flex' }}>

                    <span>  {item.name} </span>
                    <button onClick={() => {
                      handleDelete(item)
                    }}>Delete</button>
                  </div>


                </div>
              })


            }
          </div>

        </div>
      </div>
    </div>
  )
}

export default AddRecord
