import React from "react";
import AddRecord from "./components/AddRecord";

const App = () => {
  return (
    <div>
      <AddRecord />
    </div>
  );
};

export default App;
